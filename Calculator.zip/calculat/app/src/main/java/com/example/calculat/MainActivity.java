package com.example.calculat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText etFirstValue, etSeccondValue;
    TextView tvAns;
    Button add, sub, mul, div;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etFirstValue = findViewById(R.id.edFirstValue);
        etSeccondValue = findViewById(R.id.edSeccondValue);
        tvAns = findViewById(R.id.tvAns);
        add = findViewById(R.id.add);
        sub = findViewById(R.id.sub);
        mul = findViewById(R.id.mul);
        div = findViewById(R.id.div);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int first, seccond, ans;
                first = Integer.parseInt(etFirstValue.getText().toString());
                seccond = Integer.parseInt(etSeccondValue.getText().toString());
                ans = first + seccond;

                tvAns.setText("Ans is : " + ans);
            }
        });

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int first, seccond, ans;
                first = Integer.parseInt(etFirstValue.getText().toString());
                seccond = Integer.parseInt(etSeccondValue.getText().toString());
                ans = first - seccond;

                tvAns.setText("Ans is : " + ans);
            }
        });

        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int first, seccond, ans;
                first = Integer.parseInt(etFirstValue.getText().toString());
                seccond = Integer.parseInt(etSeccondValue.getText().toString());
                ans = first * seccond;

                tvAns.setText("Ans is : " + ans);
            }
        });

        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int first, seccond, ans;
                first = Integer.parseInt(etFirstValue.getText().toString());
                seccond = Integer.parseInt(etSeccondValue.getText().toString());
                ans = first / seccond;

                tvAns.setText("Ans is : " + ans);
            }
        });

    }}
